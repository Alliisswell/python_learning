# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/21 11:06
# 分隔工具：print('*' * 5, '', '*' * 5)

# ZeroDivisionError: 除（或取模）零（所有数据类型）
# IndexError: 序列中没有此索引
# KeyError: 映射中没有这个键
# NameError: 未声明或未初始化对象（没有属性）
# SyntaxError: Python语法错误
# ValueError: 传入无效参数



