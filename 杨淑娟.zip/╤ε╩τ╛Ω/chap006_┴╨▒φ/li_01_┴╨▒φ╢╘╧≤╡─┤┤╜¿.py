# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/5 21:32
# 用方括号[]
lst = [98, 'hello', True]

# 用内置函数list()
lst2 = list([98, 'hello', True])

# 空列表
kong_list_1 = []
kong_list_2 = list()
print(kong_list_1)
print(kong_list_2)
