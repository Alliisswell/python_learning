# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/6 11:22

lst = [10, 20, 30]
print(10 in lst)
print(10 not in lst)

# 遍历列表
for i in lst:
    print(i)
