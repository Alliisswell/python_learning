# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/6 10:16

# 正序、逆序索引单个元素
lst = [98, 'hello', True]
print(lst[0])  # 98
print(lst[1])  # hello
print(lst[2])  # True
# print( lst[3] )  # 不存在
print(lst[-1])  # True
print(lst[-2])  # hello
print(lst[-3])  # 98
# print( lst[-4] )  # 不存在
