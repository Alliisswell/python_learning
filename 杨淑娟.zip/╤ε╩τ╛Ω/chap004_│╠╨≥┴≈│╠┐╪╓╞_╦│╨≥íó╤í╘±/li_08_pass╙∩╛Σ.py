# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/4 14:29
# pass语句，什么都不做，只是一个占位符，用到需要写语句的地方
answer = input('您是会员吗？y/n ')
if answer == 'y':
    pass  # 还没想好接下来怎么写，就先用pass占位
else:
    pass
