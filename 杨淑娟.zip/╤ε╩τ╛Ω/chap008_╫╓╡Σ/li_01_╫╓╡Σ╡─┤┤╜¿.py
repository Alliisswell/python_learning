# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/6 17:05

# 字典dictionary

# 使用{}创建字典，{键1:值1, key2:value2, ...}
scores = {'张三': 100, '李四': 98, '王五': 45}
print(scores, type(scores))

# 使用内置函数，dict( )
student = dict(name='jack', age=20)
print(student, type(student))

# 空字典
kong1 = {}
kong2 = dict()
print(kong1)
print(kong2)
