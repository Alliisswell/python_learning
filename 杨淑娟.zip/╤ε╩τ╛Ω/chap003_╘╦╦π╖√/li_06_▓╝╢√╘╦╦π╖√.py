# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/3 14:47

"""
布尔运算符类比于c++的逻辑运算符,但是除了“与或非”，多了两个
布尔运算符有：and, or, not, in, not in
"""
s = 'hello world'
print('h' in s)
print('k' in s)
print('k' not in s)
