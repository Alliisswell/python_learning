# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/3 10:58

# input函数的使用
present = input('大圣想要什么礼物呢')
print(present, type(present))  # input()函数返回的数据类型为str
