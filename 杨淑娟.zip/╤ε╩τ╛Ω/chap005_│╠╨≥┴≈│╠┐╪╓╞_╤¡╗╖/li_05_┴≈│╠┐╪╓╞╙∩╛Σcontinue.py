# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/5 16:09

# continue用于结束当前循环，进入下一次循环，通常和分支结构中的if一起使用

# 输出5到50之间所有5的倍数

# for-in循环
# for i in range( 1, 51 ):
#     if i % 5 != 0:
#         continue
#     else:
#         print( i )


# 这里为啥不行？？？
# a = 1
# while a < 51:
#     if a % 5 != 0:
#         continue
#     else:
#         print( a )
#     a += 1
