# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/5 15:00
# a = 1
# while a < 10:
#     print( a )
#     a += 1

# b = 1
# total = 0
# while b < 5:
#     total += b
#     b += 1
# print(total)

i = 1
total = 0
while i < 101:
    if i % 2 == 0:
        total += i
    else:
        pass
    i += 1
print(total)
