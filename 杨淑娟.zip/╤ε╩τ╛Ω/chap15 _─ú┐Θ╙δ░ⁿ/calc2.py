# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/6/6 16:14
# 分隔工具：print( '*' * 5, '', '*' * 5 )

def add(a, b):
    return a + b

if __name__ == '__main__':
    print( add( 10, 20 ) )  # 只有当点击运行calc2时才会执行
