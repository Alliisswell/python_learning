# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/6/6 15:39
# 分隔工具：print( '*' * 5, '', '*' * 5 )

def add(a, b):
    return a + b


def div(a, b):
    return a / b

# 如何导入自定义模块