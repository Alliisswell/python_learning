# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/6/6 11:04
# 分隔工具：print( '*' * 5, '', '*' * 5 )

# import 包名 as 别名

import math  # 导入整个模块（如果包名过长可以起别名）

print( id( math ) )
print( type( math ) )
print( math )
print( math.pi )
print( '*' * 5, '', '*' * 5 )
print( dir( math ) )
print( math.pow( 2, 3 ), type( math.pow( 2, 3 ) ) )
print( math.ceil( 9.001 ) )
print( math.floor( 9.999 ) )
