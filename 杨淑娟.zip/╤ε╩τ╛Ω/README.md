# python_learning
The learning process of Python teached by Yang Shujuan
this is the code of python learning teached by Yang Shujuan.
