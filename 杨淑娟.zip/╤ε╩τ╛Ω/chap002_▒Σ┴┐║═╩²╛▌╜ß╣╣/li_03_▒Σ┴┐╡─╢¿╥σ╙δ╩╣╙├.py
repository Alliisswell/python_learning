# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/2 15:28

# 定义变量并且赋值（定义时必须要赋值）
name = '玛利亚'

# 变量有三部分组成：标识(id)、类型(type)、值(value)
# 标识：表示对象所存储的内存地址，用id(variable)获取
# 类型：表示对象的数据类型，用type(variable)获取
# 值：表示对象所存储的具体数据，用print(variable)打印输出
print('标识', id(name))
print('类型', type(name))
print('值', name)

name = '楚留香'
print('标识', id(name))
print('类型', type(name))
print('值', name)
