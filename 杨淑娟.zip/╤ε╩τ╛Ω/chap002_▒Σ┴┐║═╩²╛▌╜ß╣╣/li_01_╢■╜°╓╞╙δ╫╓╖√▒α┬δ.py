# 老 师：杨淑娟
# 学 生：李晓宁
# 时 间：2022/5/2 15:09

print(chr(0b100111001011000))
print(ord('乘'))  # 十进制
print(bin(ord('乘')))  # 二进制
print(oct(ord('乘')))  # 八进制
print(hex(ord('乘')))  # 十六进制
