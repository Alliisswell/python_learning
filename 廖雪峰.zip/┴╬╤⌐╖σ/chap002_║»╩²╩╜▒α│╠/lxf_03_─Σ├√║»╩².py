L = list(filter(lambda n: n % 2 == 1, range(1, 20)))

print(L)
"""
小结：
Python对匿名函数的支持有限，只有一些简单的情况下可以使用匿名函数。
"""
